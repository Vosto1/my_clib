/*
 * set a console printing color
 */
#ifndef PRINT_COLOR_H
#define PRINT_COLOR_H

#include <stdio.h>

void red();
void yellow();
void green();
void cyan();
void blue();
void purple();
void white();
void black();
void reset();

#endif